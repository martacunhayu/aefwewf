# -*- coding: utf-8 -*-
"""
Created on Wed Dec  8 15:16:06 2021

@author: Liliana Teixeira
"""
#from 1 import 

class Fakebook:
    
def help_():
    # importar constantes da main
   commands = [REGISTER, USERS, ADDFRIEND, FRIENDS, POST, USERPOSTS, COMMENT, \
            READPOST, COMMENTSBYUSER, TOPICFANATICS, HELP, EXIT]
   for cmd in commands:
       print(cmd)

# funcao que regista novos utilizadores       
def register(lst):
    
    # lista cujo 1o elemento e o user kind e o 2o e o nome do user
    lst2 = lst.split(" ", 1)
    
    user_kind = lst2[0]
    
    
    