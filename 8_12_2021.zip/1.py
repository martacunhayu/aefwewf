# -*- coding: utf-8 -*-
"""
Created on Fri Dec  3 15:20:31 2021

@author: Liliana Teixeira 62763, Marta Cunha 62949, Tomás Maia 63659, LEB
"""

#from fakebook import Fakebook

# main
BYE = "bye"
UNKNOWN_COMMAND = "Unknown command. Type help to see available commands."


# commands


# commands description
REGISTER = "register - registers a new user"
USERS = "user - lists all users"
ADDFRIEND = "addfriend - adds a new friend"
FRIENDS = "friends - lists the user friends"
POST = "post - posts a new message"
USERPOSTS = "userposts - lists all posts by a user"
COMMENT = "comment - user comments on a post"
READPOST = "readpost - prints detailed info on a post"
COMMENTSBYUSER = "commentsbyuser - shows all the comments by a user on a \
    given post"
TOPICFANATICS = "topicfanatics - shows a list of posts on a given topic"
HELP = "help - shows the available commands"
EXIT = "exit - terminates the execution of the program"

# functions

def help_():
    pass
def register(lst):
    pass
def users():
    pass
def addfriend():
    pass
def friends():
    pass
def post():
    pass
def userposts():
    pass
def comment():
    pass
def readpost():
    pass
def commentsbyuser():
    pass
def topicfanatics():
    pass
def topicposts():
    pass



def main():
   
    string = input()
    # lista cujo 1o elemento e o comando e 2o e o resto
    lst = string.split(" ", 1)
    
    command = lst[0]
    
    # avalia qual dos comandos executar
    while command != "exit":
        if command == "help":
            help_()
        elif command == "register":
            register(lst)
        elif command == "users":
            users()
        elif command == "addfriend":
            addfriend()
        elif command == "friends":
            friends()
        elif command == "post":
            post()
        elif command == "userposts":
            userposts()
        elif command == "comment":
            comment()
        elif command == "readpost":
            readpost()
        elif command == "commentsbyuser":
            commentsbyuser()
        elif command == "topicfanatics":
            topicfanatics()
        elif command == "topicposts":
            topicposts()
        else:
            print(UNKNOWN_COMMAND)
        command = input()
    print(BYE)

  
main()
